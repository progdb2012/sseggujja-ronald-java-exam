import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

class Task implements Serializable {
    String name;
    String description;
    Date dueDate;
    boolean completed;

    public Task(String name, String description, Date dueDate) {
        this.name = name;
        this.description = description;
        this.dueDate = dueDate;
        this.completed = false;
    }
}

public class TaskManagerApp2 {
    private ArrayList<Task> tasks = new ArrayList<>();
    private JFrame frame;
    private DefaultListModel<String> taskListModel;
    private JList<String> taskList;
    private JTextArea taskDetailsArea;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public TaskManagerApp2() {
    	// Initialize the main application frame
        frame = new JFrame("Sseggujja Personal Task Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        
     // Create panels for various components
        JPanel mainPanel = new JPanel(new BorderLayout());
        
     // Create and initialize Swing components
        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        taskDetailsArea = new JTextArea(10, 30);
        taskDetailsArea.setEditable(false);

        JButton createButton = new JButton("Create Task");
        JButton editButton = new JButton("Edit Task");
        JButton completeButton = new JButton("Complete Task");
        JButton deleteButton = new JButton("Delete Task");
        JButton saveButton = new JButton("Save");
        JButton loadButton = new JButton("Load");

        JPanel buttonPanel = new JPanel(new GridLayout(7, 1));
        buttonPanel.add(createButton);
        buttonPanel.add(editButton);
        buttonPanel.add(completeButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(loadButton);
        
     // Add components to the main panel
        mainPanel.add(new JScrollPane(taskList), BorderLayout.WEST);
        mainPanel.add(new JScrollPane(taskDetailsArea), BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.EAST);

     // Add the main panel to the frame
        frame.getContentPane().add(mainPanel);
        
     // Attach event listeners to buttons

        createButton.addActionListener(e -> createTask());
        editButton.addActionListener(e -> editTask());
        completeButton.addActionListener(e -> completeTask());
        deleteButton.addActionListener(e -> deleteTask());
        saveButton.addActionListener(e -> saveTasks());
        loadButton.addActionListener(e -> loadTasks());
        
        // Initialize task list and display GUI

        updateTaskList();

        taskList.addListSelectionListener(e -> showTaskDetails());

        frame.setVisible(true);
    }

    private void createTask() {
        String name = JOptionPane.showInputDialog(frame, "Enter task name:");
        if (name != null && !name.isEmpty()) {
            String description = JOptionPane.showInputDialog(frame, "Enter task description:");
            String dueDateString = JOptionPane.showInputDialog(frame, "Enter due date (yyyy-MM-dd):");

            try {
                Date dueDate = dateFormat.parse(dueDateString);
                tasks.add(new Task(name, description, dueDate));
                updateTaskList();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input or date format.");
            }
        }
    }

    private void editTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Task selectedTask = tasks.get(selectedIndex);

            String newName = JOptionPane.showInputDialog(frame, "Enter new task name:", selectedTask.name);
            if (newName != null) {
                String newDescription = JOptionPane.showInputDialog(frame, "Enter new task description:", selectedTask.description);
                String newDueDateString = JOptionPane.showInputDialog(frame, "Enter new due date (yyyy-MM-dd):", dateFormat.format(selectedTask.dueDate));

                try {
                    Date newDueDate = dateFormat.parse(newDueDateString);
                    selectedTask.name = newName;
                    selectedTask.description = newDescription;
                    selectedTask.dueDate = newDueDate;
                    updateTaskList();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid input or date format.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Select a task to edit.");
        }
    }

    private void completeTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Task selectedTask = tasks.get(selectedIndex);
            selectedTask.completed = !selectedTask.completed;
            updateTaskList();
        } else {
            JOptionPane.showMessageDialog(frame, "Select a task to mark as completed/incomplete.");
        }
    }

    private void deleteTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            tasks.remove(selectedIndex);
            updateTaskList();
        } else {
            JOptionPane.showMessageDialog(frame, "Select a task to delete.");
        }
    }

    private void showTaskDetails() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Task selectedTask = tasks.get(selectedIndex);
            String details = "Name: " + selectedTask.name +
                    "\nDescription: " + selectedTask.description +
                    "\nDue Date: " + dateFormat.format(selectedTask.dueDate) +
                    "\nStatus: " + (selectedTask.completed ? "Completed" : "Incomplete");
            taskDetailsArea.setText(details);
        }
    }

    private void updateTaskList() {
        taskListModel.clear();
        for (Task task : tasks) {
            taskListModel.addElement(task.name + " - " + dateFormat.format(task.dueDate));
        }
    }

    private void saveTasks() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("tasks.dat"))) {
            oos.writeObject(tasks);
            JOptionPane.showMessageDialog(frame, "Tasks saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error saving tasks.");
        }
    }

    private void loadTasks() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("tasks.dat"))) {
            tasks = (ArrayList<Task>) ois.readObject();
            updateTaskList();
            JOptionPane.showMessageDialog(frame, "Tasks loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error loading tasks.");
        }
    }
 // Main method to launch the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(TaskManagerApp2::new);
    }
}
